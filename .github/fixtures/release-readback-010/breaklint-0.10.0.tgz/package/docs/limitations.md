# The burden of proof, and where it stops

Two error messages in this codebase send you here. `defineRule` (`src/core/rule.ts`) refuses a
rule that carries `severity: "error"` without a named proof source, and the registry
(`src/rules/index.ts`) refuses to load if the number of error rules is anything other than two.
This page is what those messages want you to read first, so that raising the number is an
argument rather than an edit.

It also states, in one place, what this tool does not know.

## Document time and memory

The live document acquisition budget defaults to 600000 ms and is configurable through
`--document-timeout-ms` or `documentTimeoutMs` in the JSON config, within 30000–1800000 ms.
Reaching it ends with exit 3 and a message naming the budget. The budget is a hard stop, not a
speed promise. Large paginated documents can consume substantial memory: the earlier G-18
measurement found about 15.7 MiB per page during comparison. No streaming or peak-memory
improvement is part of the budget change. A fresh 200-page memory measurement is required before
claiming that the default is adequate for that document size on a particular machine.

## Why exactly two rules may fail a build

Fifteen of the seventeen candidate rules are warnings; their observations require a reader judgment
or a chosen tolerance rather than an error-level proof. A
chosen number can be wrong for your document without anything being wrong with the
measurement, so those rules do not gate by default. Two rules compare a directly measured quantity
against a boundary that is not chosen at all — and only those two gate.

| rule | what makes the boundary structural |
|---|---|
| `layout/unbreakable-block-too-tall` | The block declares `break-inside: avoid` and is taller than the page content box. There is no page it can sit on. The comparison is between two measured lengths and the threshold is the medium itself. |
| `svg/text-overflows-viewport` | The text box, normalised through `getScreenCTM()`, lies outside the SVG viewport. What is outside the viewport is not drawn. The threshold is zero, not a preference. |

## The three proof classes

A rule may carry `error` only by naming one of these in its manifest, machine-readably, as
`proofSource`. The registry rejects `error` without one, and it rejects a proof source on anything
that is not an error — either the proof holds and the rule gates, or it does not and the claim goes.

**(A) Geometric invariant.** The rule compares two *directly measured* quantities against a
structural threshold — zero, or a physical limit of the medium. A freely chosen number is not an
invariant. Both current error rules are class A.

**(B) Cited norm with its boundary.** The rule cites a specific clause of a norm or specification,
*and* names the cases in which that norm says nothing, *and* ships a non-triggering fixture for each
of those cases. If the cited norm contains a relaxation clause, the rule must additionally show that
the relaxation did not apply in the case at hand. A rule that cites a norm and ignores its exception
has not satisfied B, it has asserted B. No rule claims B today: `layout/widow` and `layout/orphan`
cite the norm correctly and are still `warn`, because no fixture reaches their error path, and a
path no fixture reaches is unverified.

**(C) Resolution invariant.** The rule compares two *directly determined* address quantities — the
resolved target of a reference and the distribution boundary of the artefact — against a structural
in/out threshold, and ships a non-triggering fixture for every case where the target lies inside the
boundary and therefore travels with the artefact. **No rule claims C.** It is defined so that
`artifact/local-uri` has a clean route to `error` in a later version, not to leave a back door open
in this one.

A freely chosen threshold may never be `error`. The three classes are three ways for a threshold
to stop being freely chosen: A and C make it structural — zero, or a limit of the medium — and B
makes it *given*, by a norm that names the number and whose exceptions the rule has ruled out. A
rule that satisfies none of the three is at most a warning, however confident its author is.

This distinction matters because the word "uncalibrated" is doing two jobs elsewhere in this
project. It means: no corpus of human-labelled documents backs this number. That is true of all
seventeen registered candidate rules, including the two error rules — and it does not disqualify them, because their
numbers are not up for calibration in the first place. A block taller than the page fits on no
page; the threshold is the page. What calibration would decide is *where to draw a chosen line*,
and A, B and C are exactly the cases where no line was chosen.

**One more condition, and it is the one that actually bites.** A rule may carry `error` only if a
fixture that triggers exactly that error path exists in the corpus. This is what disqualifies the
widow and orphan rules — not doubt about the norm.

## Coverage floors

An `error` rule that could not measure everything it needed is not silently downgraded to a pass.
Coverage is reported per rule and floors apply by severity: `error` demands full coverage, `warn`
demands half, `info` demands none. Falling below the floor produces exit 4, `insufficient-coverage`,
which exists because of a measured case: a multi-column document once produced six pages analysed,
one rule run, five candidates, zero measured — and exit 0, indistinguishable from a clean run.

Configuration Contract v1 can make those floors stricter, but cannot lower them. The `strict`
profile sets every floor to 1. The two proof-source-A thresholds are not configurable at all:
turning a structural boundary into a caller preference would invalidate the reason those rules may
gate by default. The effective floors and their origins appear in the report (schema 3 from 0.2.3,
schema 4 from 0.5.0, schema 5 when the optional `remediation` was added to a finding); stored
snapshot fixtures moved to schema 3 in 0.2.3, when `inkCollected` was added, and to schema 4 in
0.5.0.

### What coverage is a ratio OF, and the two things it is not

Coverage answers a per-rule question about the DOCUMENT: of the candidates this rule ought to
have judged, how many did it judge? Cross-rule totals sum rule-candidate evaluations, not unique
objects or independent defects. A table evaluated by two rules contributes to both. Applicable
unmeasured evaluations are displayed separately from not-applicable and unavailable-tool counts. Two kinds of decline are therefore not in the denominator, and both are
enumerated in `src/core/enums.ts` rather than inferred from how a reason is spelt.

**A capability represented only in research code** (`TOOL_CAPABILITY_ENV_IDS`). The SVG ink passes
are not implemented in production. Version 0.3.1 therefore removes `svg/text-clipped` and
`svg/text-ink-collision` from the public registry instead of making their permanent decline part of
every user's coverage. The enum and the two modules remain for the frozen M3 validation lab; the
released CLI, schema and SARIF catalogue never run them.

**A question that does not arise** (`NON_APPLICABLE_ENV_IDS`). With `overflow: visible` an SVG's
text is painted whether or not it leaves the viewport, so `svg/text-overflows-viewport` has
nothing to decide about it — as with an SVG holding no text. One such figure would otherwise drive
an error rule below its floor of 1 and end the whole run in exit 4.

A third case is not a decline at all: a `<text>` that is not painted. Inside `<defs>`, `<symbol>`,
`<clipPath>` or `<pattern>`; under `display: none`; or hidden by `visibility: hidden`,
`opacity: 0` or a missing fill and stroke. None of it is a target of a rule about what the
viewport clips away, so none of it is counted or declined.

Both halves have to be measured rather than read off the markup. Chrome answers `getBBox()` and
`getScreenCTM()` for an element in `<defs>` and yields a box far outside the viewport, which a
gating rule will report as an error about something nobody can see — so the collector asks
`getBoundingClientRect`. And the invisible cases lay out perfectly normally and return a full
rect, so the empty-rect check does not see them at all — those come from the computed style. Each
was found by building the fixture for the previous one.

A `<text>` that IS laid out and still has no readable box declines with `env/svg-ctm-unavailable`
and DOES count against coverage — that is a measurement this tool owed and did not deliver, per
target rather than per SVG. The same fail-closed rule applies when a box exists but does not prove
the painted result: `<use>`, paint servers, text decoration, clip paths, masks and filters decline
with `env/svg-painted-bounds-unsupported`. Visible strokes do so unless a conservative outer bound
of the stroke fits wholly inside the SVG viewport.

Neither exemption leaves the report. Both keep their rule, reason and count in `notMeasured`, and
each rule's own books are still checked first: `defineRule` requires measured plus declined to equal
candidates, and only afterwards does the engine subtract. A decline that names a property of the
INPUT — `env/multicolumn`, `env/svg-ctm-unavailable`, `env/svg-too-many-text-targets` — stays in
the denominator, because another document would have been measured. That is what exit 4 is for,
and `tests/unit/coverage-base.test.ts` holds both halves of the pair so that widening the
exception to cover the second kind turns a test red.

## What no amount of testing here establishes

**Two research rules are not product rules in this build.** `svg/text-clipped` and
`svg/text-ink-collision` need isolated, stable SVG pixel passes, which remain M3 work. Their modules,
fixtures and renderer lab are retained so the work is not erased, but they are absent from
`ALL_RULES`, configuration, SARIF and the demo. The candidate registers seventeen rules; these two research modules are not among them.
`svg/text-overflows-viewport` needs only geometry and does measure.

**Complex SVG paint is detected but not geometrically solved in this build.** `querySelectorAll`
does not cross the instance tree created by `<use>`, and `getBBox()` does not include stroke,
clipping, masks or filter effects. The collector detects those entrances and keeps each as an
unmeasured candidate unless the narrow stroke proof below applies. Because the viewport rule is an
error rule with a coverage floor of 1, even one undecidable target produces
`insufficient-coverage` (exit 4), never a silent clean result or a guessed error. Full support
belongs to the independent ink passes.

*What this costs on a real document, measured.* The entrance that fires in practice is not `<use>`
or a filter — it is the **halo**: `paint-order="stroke fill"` with the stroke set to the background
colour, the standard way to keep a diagram label legible where it crosses a line. Over an
eighteen-document reference set of illustrated chapters:

| document | `<text>` candidates | measured | declined | trigger |
| --- | --- | --- | --- | --- |
| 03 | 30 | 30 | 0 | — |
| 05 | 24 | 24 | 0 | — |
| 09 | 23 | 20 | 3 | 3 haloed labels |
| 02 | 45 | 30 | 15 | 15 haloed labels |
| 07 | 27 | 10 | 17 | 17 haloed labels |

Read the first two rows before the last three: inline SVG text is **not** structurally unmeasurable
here, and a document whose labels carry no visible stroke measures at coverage 1. The table is a
dated pre-change measurement: then every visible stroke declined because `getBBox()` returns the
fill outline, not the ink. Three haloed labels were enough to make the error rule end exit 4.

G-114 admits only a finite CSS-pixel stroke width, known cap and join, finite miter limit, no
descendant paint override, vector effect, or text/inner-ancestor transform, and an intact CTM. It
expands the local box by a deliberately conservative radius using the full
`stroke-width × stroke-miterlimit` for miter joins (the [SVG 2 painting definition](https://www.w3.org/TR/SVG2/painting.html#StrokeLinejoinProperty)
defines the ratio), carries that envelope through the CTM, and
measures only if all four sides remain strictly inside the viewport. A boundary-touching halo
stays `env/svg-painted-bounds-unsupported` and still causes exit 4. This proves containment for
that narrow case; it does not identify painted bounds exactly or turn a partly outside stroke into
a finding. A painted stroke on a `<tspan>` or other descendant declines even if the outer `<text>`
has `stroke="none"` or no paint of its own; descendant paint remains a candidate, never a silent
clean result. The dated corpus counts above are not a claim about current coverage.

**Nontrivial viewport boxes are detected but not reconstructed.** `getBoundingClientRect` is the
border box and becomes only an axis-aligned envelope under rotation or skew. An SVG root with
border, padding, rounded clipping or a nonzero overflow clip margin therefore declines, as does an
SVG whose own or ancestor CSS transform geometry is nontrivial (`transform`, the individual
`rotate`/`scale`/`translate` properties, perspective or motion path). The reason is
`env/svg-viewport-geometry-unsupported`. Ordinary axis-aligned SVG roots remain measured. A later
content-quad implementation needs its own transform-aware live proof.

**Every threshold is uncalibrated.** A [human evaluation of ten selected real pages](evaluation-0.10.md)
now supplies bounded labels and feedback. It does not establish a representative truth corpus
behind the seventeen candidate rules. The fixtures show that each rule does what it says; they do not
show that what it says is the right thing to say about your document. That is the difference between
bounded implementation/renderer validation and accuracy across independent real documents;
only the named bounded checks and selected human examples are claimed. `calibrated: false`
travels in the type, in every finding and on every rule page for that reason.

**A document whose paginator could not place its content is not measured at all.** Paged.js
fragments a page by making `.pagedjs_page_content` a multi-column container whose pitch is the
content width plus a gap of `margins + bleed + 1000px`. What it fails to move onto a new page stays
in the second column, one pitch to the right, invisible behind an `overflow: hidden` sheet. Where
that content is a table box, `page.pdf()` — which renders in print media, with a re-sized
fragmentainer — puts it somewhere else and leaves it there, so the PDF does not reproduce the
geometry the rules measured. The run ends in exit 3 with `render-unstable`, and the event names the
elements, their source ids, the pages and the column pitch. It is not a rule finding and cannot
become one: nothing about the pages that DID lay out is reported, because the state they were
measured in was withdrawn.

Measured over eighteen chapters of one shipped HTML bundle: 6 of 6 documents with table residue in
an overflow column could not be measured, 12 of 12 without it could. Two of those twelve carried
residue of other kinds — one `<p>`, one `<em>` — and measured cleanly, because ordinary block
content re-fragments to the same boxes. Nothing exotic produces this: no `@page`, no print
stylesheet, no `break-inside` and no script are needed, only a table that crosses a page boundary.

The six documents are recorded, not published. They are chapters of a paid product, and this
repository is public and MIT, so `corpus/public/pagination-residue-v1` keeps their SHA-256 values,
rights and privacy review and exact expected residue while their bytes stay outside it —
the `private_nonredistributable` shape of `docs/validation/corpus-contract-v1.md`. That record is
now historical: re-measured on 2026-09-18, five of the six documents and their shared stylesheet no
longer exist at the recorded digests, so nobody can run its private half. `npm run
test:pagination-residue` prints `NO CLAIM` and reads none of the six, with or without
`BREAKLINT_RESIDUE_CORPUS_ROOT`, and it is no longer a CI or release step — a step that exits 0
having read zero documents would be a green light over nothing. What holds this class in CI is the
public `tests/fixtures/fragmentainer-residue.html` in the live suite, reduced from one of the six
until no product text remained; the reduction is itself the measurement that nothing exotic is
required.

**Rendering is not reproducible across machines.** Browser rendering varies with the host operating
system, browser version, settings, hardware and headless mode. PNG output here is evidence, never a
comparison basis, and no check compares output file hashes.

**Findings depend on font availability.** A missing `@font-face` changes metrics, line breaks and
page breaks, and can turn a correct page into a phantom finding. The run waits for
`document.fonts.ready` and stops with a non-zero exit if a declared font resource fails, rather than
reporting findings it cannot stand behind.

**Missing image content is a named limitation, not a silent success.** A failed decode is non-fatal
only when the HTML declares positive `width` and `height` attributes and Chrome measures a box
exactly equal to both values. The report then carries `image-content-unavailable`, a resource index
and both declared and rendered dimensions without persisting the URI. Missing dimensions,
replacement-text geometry, zero-size boxes or authored CSS that changes the box remain fatal
because the absent pixels can change layout.

**One paginator version.** Paged.js is pinned to exactly 0.4.3, because the break cause is read from
attributes the paginator writes into the tree and does not guarantee as an interface. Any other
resolved version stops the run with exit 3, and no flag overrides it.

**Windows is not supported.** Process termination rests on POSIX process groups; the termination
and profile-cleanup path has real evidence on macOS only, and Windows job objects are neither
designed for nor measured.

**Linux was unmeasured, then measured, and what it showed was a defect.** The first public CI run
failed: the evidence binding broke on every document, because the marks shared a font with the
document's own text and the resulting font-subset difference registered as contamination. The
cause is fixed, and the fix is measured — the full live suite, 57 cases including the hostile
corpus and the independent rasteriser cross-check, is green in a Linux container (arm64, Chromium
151, poppler 22.12), against 15 red cases with the fix removed.

That is no longer only a container result: the fixed commit has since run on the x86_64 CI
runner, where the same step that reported the defect now passes. What remains true is narrower —
the process-termination and profile-cleanup path has empirical evidence on macOS only. Linux is
measured for the measurement chain, not yet for the process lifecycle.

There is deliberately no `os` field in `package.json`, which means npm will install this on
Windows without complaint. That is not an oversight: `--demo` and the whole rule and reporter
chain need no browser and no process group, so they work there. What does not work is a run over
your own HTML. Blocking the install would take away the part that functions in order to prevent
the part that does not, and the part that does not already fails loudly rather than quietly.

**Non-HTML input is refused by its name, not by its content.** An input path that does not end in
`.html` or `.htm` — Markdown, PDF, a standalone SVG — ends with exit 2 and `unsupported input type`
before any renderer starts and before the path is even opened; measured for a `.md` file, existing
or missing: exit 2, nothing on stdout. A path that is not a regular file — a directory called
`chapter.html`, for instance — is refused the same way with `input is not a regular file`; through
0.6.0 it passed both checks, started Chrome and ended exit 3 with "resource byte limit exceeded".
The content of a `.html` file is not sniffed. Markdown text
saved under a `.html` name is served and parsed as HTML: one run of body text with no element in
it. Such a run then ends with exit 3 and `geometry-cross-check-failed` ("measured no elements"),
because a cross-check over zero elements is not a passed cross-check (`src/measure/cross-check.ts`)
— measured locally on Chromium 141 with the evidence binding off; the zero-sample rule itself does
not depend on the browser. A converter's HTML output is ordinary HTML and is measured as such. The
paragraph that stood here through 0.6.0 described a Paged.js `pagination aborted` exit 3 for a
Markdown file; that path is gone, because the name check runs first.

**Foreign HTML is executed, and the offline policy is not an egress control.** The run uses a
fresh browser profile, never asks for the sandbox to be off, and intercepts the page's requests,
letting through only its own loopback origin (plus `data:`, `blob:`, `about:` and any
`--allow-network` origin). Interception does not cover WebSocket, WebTransport or WebRTC
connections a document opens, nor the browser's own traffic — secure DNS (DNS over HTTPS) and the
component updater. Measured on 0.7.0 in the default offline mode with a self-authored document: a
WebSocket to a loopback port that was not the tool's was delivered, a WebRTC STUN request was sent,
and the run came back `clean`. In 0.8.0, breaklint refuses to launch if
`PUPPETEER_DANGEROUS_NO_SANDBOX` or `PUPPETEER_TEST_EXPERIMENTAL_CHROME_FEATURES` is present, and
removes `CHROME_EXTRA_FLAGS` from Chrome's child environment. This closes those known environment
paths; other wrapper variables are not generally audited. For a document you do not trust, run
breaklint in a container or network namespace with no egress. The GitHub Action's empty
`allow-network` input applies this same interceptor policy; it does not make the runner fully
offline. See [SECURITY.md](../SECURITY.md).

The longer, measurement-by-measurement account of what has been established and what has not is in
[status.md](status.md).

## The break cause of a page boundary

A `forced` boundary records a decision made by Paged.js; its rationale and author intent are
unknown without verified source/design evidence. `layout/widow` declines the fragment opening
after it, `layout/orphan` the fragment closing before it and `layout/orphaned-continuation-page`
the page after it (`env/forced-break`, counted against coverage). Experimental half-empty-page
also declines an outgoing forced low-coverage case when it has no late start. A natural document
ending is measured without a low-coverage warning. Neither outcome labels author intent.

**The cause is the decision Paged.js' `shouldBreak()` took, evaluated again at the break token.**
When a page is laid out, Paged.js 0.4.3 hands the collector a break token naming the node of its
parsed source at which the next page starts. The collector evaluates the three clauses of
`shouldBreak()` there, with the paginator's own rules: the node's `data-break-before` (unless it
repeats its parent's and no node precedes it), its `data-previous-break-after`, and
`needsPageBreak()`, which compares the named page in force at the node (its own `data-page`, else
its nearest ancestor's) with the one in force at the node **before** it — a previous sibling, or an
ancestor's previous sibling, whose named page comes from itself and its ancestors, never from its
descendants. Only a token at the node the layout walker handed out last on the page can be
forced — layout.js asks `shouldBreak()` about each node it walks, immediately before laying it
out, and breaks at that node — so the collector records it from the `layoutNode` hook. A token
that points into a node (an offset) was not forced: `shouldBreak()` was asked of that node where it
started. Nor was a token at a node the walker never handed out: Paged.js deep-clones `p`, `li`,
`td`, `dd`, `dt`, `blockquote`, `h1`–`h6`, `pre` and `figcaption`, so a `break-before` or `page:`
on a block inside one is never evaluated, and an overflow can still end a page exactly at that
block. Measured: a list whose items each hold a `break-before: page` box classified as forced at
every such overflow, 36 widow and 36 orphan candidates declined and exit 4, against the same list
without the declaration at exit 0; now both end exit 0 with the same findings. The boundary is then, in this order: `parity` when the next page is
blank; `unknown` when there was no token or it carried no node; `forced` by a forcing break-before,
break-after or named-page difference; `overflow` otherwise. `unknown` suppresses nothing.

**Two readings of the finished pages were measured wrong, and neither is used.** Through 0.6.0 the
named page was taken from each page's first source-bearing node, which on a real document is
usually a wrapper — `<main>`, `<article>` — continuing from the page before, with no named
ancestor: every boundary inside a named region and the one after it read as `forced`, and the
boundary into the region as `overflow`. Measured on a self-authored report with a landscape region
(patched Chromium 141, no evidence binding): 9 of 14 widow and 9 of 14 orphan candidates declined
as `env/forced-break`, both below the coverage floor, exit 4; now 2 of 14 each, at the two
boundaries the paginator forced. A first repair compared the named pages
the two pages were **styled** with — the `pagedjs_<name>_page` classes on the page element — and
that is not the paginator's rule either: the classes record which `@page` rule a page got, not
whether a break was forced. `<div><section style="page: chap">…</section></div><p>` does not break
on leaving the section, because the paragraph is compared with the `<div>`, and it is laid out on
the `chap` page; the next overflow boundary, where the page style changes, was then called
`forced`. The same first-node read also missed a `break-after` whose following element sits inside
a continuing wrapper, and one followed by loose inline content: Paged.js puts
`data-previous-break-after` on that following element, which may be an `<em>` at the head of the
page. The live suite checks every boundary of its named-region documents against Paged.js' own
`shouldBreak()` answers, recorded by a test-only wrapper around it.

What remains:

- **It reads Paged.js internals.** The token's node, the three attributes Paged.js writes into its
  parsed source and the shape of `shouldBreak()` are not an interface; the version pin above is
  what bounds that.
- **A page Paged.js inserts for parity has no token**, so the boundary out of it has no decision
  of its own; both edges of a blank page are `parity` by the page rule.
- **An element hidden with `display: none` and carrying `page:` still breaks.** Paged.js compares
  its named page like any other element's, so the page it would have started is forced although
  nothing visible starts there, and the tool reports the break as `forced` because that is what
  the paginator did.
- **A `break-after` reason names the last source node before the boundary**, which is the element
  that declared it only when that element ends its page itself — a paragraph, not a section
  around it. A forced boundary's reason otherwise names the nearest source-bearing element at the
  token's node: an inline element carries no source id, so a break at an inline named page names
  the paragraph it is in. The classification does not depend on the reason.

## Raising the number of error rules

The registry's literal `2` is not a constant to be updated when a sixteenth rule feels important. To
change it: name the proof class, ship the fixture that reaches the error path, ship the
non-triggering fixtures the class requires, add the argument to this page, and only then change the
number. The failing registry check is the reminder that the order matters.


## Source-bound 0.5.0 limits

The expanded robustness review is **partial**. Real Digital Product Studio inputs and independent third-party template groups were exercised, but not all admitted candidates paginated successfully. Some W3C/Alice candidates stop with DOM/PDF divergence, pagination residue or source-order mismatch. These are nonmeasurement results. Version 0.5.0 does not claim a complete broad-template robustness pass or increase calibration/trust status.

The screen profile measures the **currently visible viewport rectangle**, including when a full-page screenshot is requested. Below-fold nodes are explicitly excluded; the host must open and check additional scroll states. Authored scroll containers and intentional overlays use named exceptions. Source binding is a verified host-build container when supported, not a JSX line-level source map. Screen reports have no automatic `resolved` repair-comparison path.

Document repair comparison is limited to preserved, unambiguous author anchors, a compatible complete document set, verified local Git continuity and captured actual font identity. Page-only findings remain unmatchable; system/fallback font identity and reduced or absent measurements prevent a repair claim. CSS resources must be captured as dependency/asset inputs; the host's authoring documents are not a resource allowlist.

The real Studio repair attempt was performed by an independent agent. No fresh human usability trial, two-week field trial or measured long-term time saving is claimed. The technical surface gate and visual agent review do not replace the separate human surface ledger.


## 0.6.0 limits


**A per-fragment applicability decision can be silent about a property of the whole element.**
`layout/unbreakable-block-too-tall` skipped every fragment after the first and therefore compared
the height of a *piece* against the page. Measured on 2026-09-18: a six-page `break-inside: avoid`
section came back `clean` at exit 0, fragment 0 reading 596.36 px against a 680.31 px page. That
particular rule now sums its fragments. The **class** is not closed: every rule in this registry
decides applicability per fragment, and any future rule whose quantity belongs to the element
rather than to the piece can repeat this. There is no gate that detects the shape; what caught this
one was a red control that had quietly stopped being red.

**How often oversized `break-inside: avoid` blocks occur in real documents is not measured.** The
repair is arithmetically correct and conservative, but its frequency in the field is unknown, so
how much this changes in practice for a given project is unknown too. A project that sees a new
`error` after upgrading is seeing a block that never fitted; that is all this version claims.

**A two-fragment split is measured but never reported, and that is a proof obligation.** Paged.js
does not fragment natively — it produces two DOM elements — so `box-decoration-break` does not
apply here at all. What strips decoration at a split is Paged.js' own stylesheet, and it unsets
`margin` and `padding` on `[data-split-from]`/`[data-split-to]` but **not** `border`, and without
`!important`. A bordered block that is split therefore carries its border height once per fragment,
and an author rule with `!important` padding does the same — so two fragments can sum above the
page for a block that fitted unsplit. From three fragments on that cannot happen: an intermediate
fragment fills an entire content box and there is content before and after it, so the block is
taller than one page by construction. **The residual gap is a block split into exactly two
fragments whose real height does exceed the page: it is not reported, and the value recorded for it
is the first fragment's box rather than the sum** — exactly as in 0.5.0, and stated here because a
reader of the summed-height paragraph above would otherwise assume the sum is recorded everywhere. The residual risk
in the other direction is a block with borders thicker than the content of its own outer fragments,
which would have to be several tens of pixels per edge.

**The boundary is the content box of the page the block was laid out on.** Comparing against the
largest content box in the document was tried and is worse: in a document with a named landscape
page it raises the bar for every block on the portrait pages and hides real ones. What is observed
is that this block did not fit unbroken on this page, and that is what the finding says — it no
longer claims anything about pages it did not measure. A block that would have fitted on a
differently sized page elsewhere in the document is still reported, because it still broke its own
`break-inside: avoid` where it was.

**`kill(pgid, 0)` answering `EPERM` is read as indeterminate, not as failure.** Measured on darwin
25.6.0, macOS answers `EPERM` transiently for a process group this process created and owns while
that group is being torn down — 8 of 20 acquisitions, every one followed within 10 ms by `ESRCH`
with the descendant dead. The producer cleanup therefore retries inside its existing bounded
deadline instead of failing on the first sample. What this does NOT establish is the kernel reason
for the answer; the behaviour is measured, not explained, and it was measured on one platform and
one version. An `EPERM` that outlives the deadline still fails the acquisition. The retry itself
and the deadline-expiry failure have **no test**: both live in closures that only run when the
environment produces `EPERM`, which is not deterministic. What is pinned is the errno truth table.

**The 40-document corpus behind the `layout/half-empty-page` default is not in this repository.**
The 37-of-40 figure was measured on a corpus constructed for that purpose during the same work, and
it is not admitted here, not hashed here and not reproducible from this repository. Every place that
cites the number says "a corpus constructed for this purpose"; this paragraph says the rest of it.
The decision it supports is reversible by configuration and moves no exit code either way, which is
why it was taken on that evidence — the same standard would not have been enough for a gating rule.

## 0.7.0 limits

**In 0.7.0, `body { column-count: 1 }` could end `clean` over a PDF that lost most of its content.**
`column-count: 1` or `columns: 1` on `body` makes the body a multi-column container, and Paged.js
then lays its pages out inside it. Measured by
independent verifications of this release cycle: the produced PDF was missing most of the
document's content — in one run it held one page and about half the words — while the run
reported its pages as measured and ended `clean`, exit 0. In 0.8.0, a computed print `column-count`
or `column-width` on `body` ends exit 3 before the source can be called clean. This refuses even
one-column bodies because Paged.js may create its own pagination columns inside them. It is a
guard against this known failure mode, not a general multicolumn completeness proof.

**In 0.7.0, a `display: contents` heading split at a page break could lose its continuation.**
Paged.js does not carry the rest of such a heading to the next page: measured by an independent
verification of the 0.7.0 cycle, 17 of the heading's
89 words were printed, and the run ended exit 0. In 0.8.0, any nonempty heading with computed
print `display: contents` ends exit 3, including headings that would have fit. The guard names the
style; it does not attempt to reconstruct missing text after pagination.

**Nothing printed in a page margin box is measured by any block, line or page rule.** Paged.js
implements `position: running(...)` by deep-cloning the element into the margin box of every page,
and `position: fixed` by cloning it into every page box; both clones keep the injected source id.
The collector used to gather blocks from the whole `.pagedjs_page`, so every clone became one more
"fragment" of its source block. Measured on 2026-09-24 with Paged.js 0.4.3: a six-page document
with a one-line running title and an eight-line side running element carried seven records per
element and reported ten `layout/widow` and `layout/orphan` warnings, every one about a clone; under a running header,
the blank page a `break-before: recto` inserts was not blank, both of its boundaries came out
`overflow`/`forced` instead of `parity`, it drew a `layout/orphaned-continuation-page` finding, and
every page was anchored to the header, so three `layout/half-empty-page` findings on three pages
shared one fingerprint. An earlier repair of the one symptom that could fail a build —
`layout/unbreakable-block-too-tall` summing the clones — decided flow membership in that rule by
coordinates, and that test also discarded every fragment of a full-bleed block (see below).

The snapshot, the collector and the evidence overlay now all keep only source blocks inside a
page's content area, `.pagedjs_pagebox > .pagedjs_area`. That area holds the page content **and the
footnote area**: footnotes stay part of the page they are printed on, as before. It is an inclusion
test on the page structure rather than an exclusion by class name, so author markup that happens to
carry a `pagedjs_margin` class does not leave the flow, and a page with no content area stops the
run (exit 3) instead of being measured as empty. What that leaves unmeasured, stated because no rule
reports it:

- **Margin-box content.** A widow, an oversized block or an unfilled band inside a running header or
  footer is not judged. Generated margin content (`@top-center { content: "…" }`) never was.
- **A running element keeps exactly one record**: the in-flow original Paged.js leaves in the page
  content with an inline `display: none`. Snapshot 7 retains each block's computed `display` and how
  many margin-box copies of it Paged.js printed (`marginCopies`), so the block rules that could
  select the original — `layout/unbreakable-block-too-tall`, `layout/heading-at-page-bottom`,
  `type/excessive-word-spacing` — record it as `excluded` with the reason
  `rule/target-in-margin-box`, outside the coverage base, and never as measured. Until this repair
  it counted as measured at 0 px, and a document whose only avoid block was a running element
  reported full coverage for a check that looked at nothing. An element the author hid
  (`display: none`, no margin copies), or one inside a hidden subtree or a closed `<details>`, is
  `rule/target-not-rendered`. The type rules still read a running element's source text once,
  attributed to that hidden position, where there is no box for evidence to mark. A page is
  anchored to its first rendered block, so the hidden original never anchors one.
- **A `display: contents` block is judged by what it prints, never by its zero box.** It generates
  no box of its own while its text and children are laid out. `layout/unbreakable-block-too-tall`
  asks about a box, and `break-inside` does not apply to an element without one, so such a block is
  `not-applicable` with the reason `rule/target-generates-no-box`, outside coverage; its children
  are candidates in their own right. (An unreleased intermediate state declined it against
  coverage instead, and a key/value grid whose `li` items were flattened with `display: contents`
  under a print rule `li { break-inside: avoid }` ended exit 4 with twelve declines, where it had
  ended exit 0.) An
  image-only `display: contents` figure is the same case, not an unrendered one.
  `layout/heading-at-page-bottom` places such a heading, and a block below it, by its visible line
  boxes; with no visible line but recorded lines it is excluded as `rule/target-not-visible`, and
  with no line or unrecorded lines it is declined as `env/invalid-measurement`, counted.
  `type/excessive-word-spacing` reads the visible lines of every block: lines that are all
  invisible are `rule/target-not-visible`, a block with no line at all (empty, or image-only) is
  `rule/no-text-lines`, and lines the snapshot did not record are declined as
  `env/invalid-measurement` — never a measurement of factor 0.
- **A box of zero by zero is not by itself "not rendered".** A block counts as not rendered only
  when the snapshot shows nothing printed from it: `display: none`, or recorded lines none of which
  is visible (an element inside a hidden subtree or a closed `<details>` has no line box). A
  zero-size block that is neither — `width: 0; height: 0; overflow: visible` prints its text
  outside the box, or its lines were not recorded — is placed by its visible lines where the rule
  reads positions (`layout/heading-at-page-bottom`, and the continuation rule's flow), measured
  from its lines by `type/excessive-word-spacing`, and declined as `env/invalid-measurement`,
  counted, by `layout/unbreakable-block-too-tall`, whose question is the height of a box that
  printed nothing of its own. A line is visible when any text on it is: visibility is read from
  each text node's element, so `p { visibility: hidden } span { visibility: visible }` prints and
  is measured. What remains: `layout/unbreakable-block-too-tall` still reads the BLOCK's own
  visibility, so a hidden block with a visible descendant is excluded there as not visible.
- **A split block is judged at the first fragment that printed.** `layout/unbreakable-block-too-tall`
  takes the block's lead fragment to be the first one laid out with a box of its own and visible,
  joined by source id; earlier fragments are recorded `not-applicable` as
  `rule/fragment-not-rendered`. Measured on 2026-09-25 with hostile documents: a script that set
  `display: none` on only the first fragment of a four-page avoid block, or marked it as a note and
  moved it into the footnote area where it has no box, hid the whole block (exit 0, where the base
  reported it at exit 1), because the later fragments were skipped as continuations of an excluded
  candidate. What remains: a script that hides EVERY fragment hides the block, which is then also
  not printed; a script that changes the first printed fragment's own `break-inside` changes the
  question the rule asks; and a two-fragment block whose first fragment is hidden is judged by the
  second fragment's box alone, as every two-fragment block is (see the rule page).
- **A `position: fixed` element is not measured at all.** Paged.js removes it from the flow, so there
  is no in-flow original, and its per-page clones are outside the content area. (An element whose
  `position: fixed` is an INLINE style is not recognised by Paged.js at all: it stays in the flow,
  is measured there, and is painted at the viewport origin, where its evidence marks cannot be
  placed.)
- **Markup that reproduces the page structure inside a running element comes back into the flow.**
  The test asks whether an element has an ancestor that is the area child of a page box. A running
  element whose own markup contains `<div class="pagedjs_pagebox"><div class="pagedjs_area">` makes
  its descendants pass that test in every margin-box clone, so they are measured once per page again
  — the pre-repair behaviour, with its false `layout/widow` findings and shared fingerprints, for that markup only.
  It cannot hide flow content from measurement: that would need an element of the real content area
  to lose the ancestor it has. A class name alone (`pagedjs_area` without the page-box parent) does
  not pass the test.
- **Inline SVG inside a margin box is still collected once per page, and SVG text there stops the
  run.** The SVG collector still reads the whole page, so a running element that contains an SVG
  contributes one SVG record per page, all with one key. When that SVG carries `<text>` and the
  element repeats on two or more pages, every clone carries the same injected target id,
  `svg/text-overflows-viewport` sees one target evaluated twice, and its accounting invariant ends
  the run `checker-crashed` (exit 3). Measured on 2026-09-24 on a three-page document with a
  running logo; it predates the flow repair above and is not changed by it.
- **Footnotes are in the flow, but a document with footnotes does not reach the rules.** Measured on
  2026-09-24 with the real paginator: a block footnote moved into the footnote area is recorded on
  its page and is an edge of that page's flow, and the source-id check accepts its position after
  the page content (`tests/live/breaks.test.ts`). The production run stops before any rule, though:
  Paged.js gives each footnote call an `href` built from the paginator's per-run random `data-ref`,
  the paired control run reads that as a changed resource, and the run ends
  `injection-interference` (exit 3). That holds for block and inline footnotes alike, before this
  repair and after it. Before it, a block footnote already stopped the run one step earlier, at
  the source-id order check.

**The source-id integrity check reads the order of the flow; copies outside it are checked for
identity, presence and the signature of the Paged.js step that put them there, not for order.**
Paged.js puts three kinds of copies out of source order: a running element's clones in the margin
boxes (which come before the content area in every page box), a block footnote in the footnote area
(after the page content) and a `position: fixed` clone at the head of every page box. The check used
to read every source id in the document in document order, so a running title that was not the
first element of the source — a heading before it, or a section around it — ended the run
`checker-crashed` (exit 3). What still fails the run: any attribute change of a reserved id,
anywhere; an unknown id, in the flow or out of it; an expected id that is nowhere; a flow whose
order differs from the source; an id found only in margin boxes, without the in-flow original every
running element keeps; an id in the footnote area outside an element Paged.js marked as a note
(`data-note="footnote"`); and an id in a page box that is not on every page, sits after the page's
content area, or also occurs in the flow — none of which Paged.js produces for a `position: fixed`
element. Each of those is an element a script moved out of the flow. What the signature cannot
tell apart is a script that reproduces it exactly — marks an element as a note before Paged.js moves
it, or clones it into the head of every page box and removes the original.

**Evidence marks follow the same boundary, and three kinds of page still cannot bind.** The overlay
places no mark on a margin-box or page-box clone: no finding can target one, and requiring a mark
for it left every page of a document with a running header unbound, so that the default run
(evidence binding on) ended exit 4 — measured on 2026-09-24 before this repair, with 24 unplaced
marks on a six-page document with two running elements. A fragment that bleeds into the side margin
is marked where it is printed, inside the page box; before this repair all 212 marks of a full-bleed
document were refused; measured after it, every one of the 212 is laid out exactly where the overlay
recorded it and inside the page box. Whether the PDF text layer then returns each mark at that
position can only be checked on a browser whose PDF carries the marks: the Chromium 141 build these
repairs were developed on writes a PDF with no mark in it at all, in the margin or not, so that
half is established by the live suite on current Chrome in CI and nowhere else. What does not bind,
and so ends a run with evidence binding on at `insufficient-coverage` (exit 4):

- a page whose flow contains a fragment pulled ABOVE or below the content box (a negative top
  margin, content hanging past the column): down the page a mark must lie inside the content box,
  so that mark is refused, and a fragment with no mark on its page leaves the page unbound. The
  bound is a conservative choice, not a measured necessity: the marks hang in Paged.js'
  multi-column fragmentainer, and on Chromium 141 a mark positioned above or below it printed at
  its DOM position; the vertical bound was kept rather than rely on that for every browser;
- a page carrying a footnote-area block, for the same reason (the footnote area lies below the
  content box) — moot today, because footnotes stop the run earlier;
- **a page with no source block at all, such as the blank page a `break-before: recto` inserts.**
  A page binds only on marks it carries (`src/render/evidence.ts`), and required evidence is
  complete only when every page binds (`src/core/engine.ts`), so every document with a
  parity-blank page ends exit 4 under evidence binding, with or without running elements. That is
  the evidence contract as it stands, read from the code; the margin-box repair did not change it.

**A page is anchored to the first block that starts on it.** A block that spans pages — `<main>`,
`<article>`, a section, a full-bleed block — has a fragment on every page it covers, and as an
ancestor it comes first in document order, so it used to anchor every one of those pages: the page
findings on them shared one fingerprint. Now the first block whose first fragment is on the page
anchors it. Only a page on which nothing starts — the middle of a single block taller than a page —
falls back to its first continuing block, and two such pages of the same block share an anchor. A
wrapper that starts on page 1 still anchors page 1, keyed by its author id or, without one, by the
signature of all its text, so without an id that page's fingerprint follows any edit inside the
wrapper.

**Flow membership is decided by page structure, never by coordinates, so a fragment that bleeds
into the margin still counts.** `layout/unbreakable-block-too-tall` sums every record carrying the
element's source id. A coordinate test ("a real fragment starts inside the content box") cannot tell
a margin box from a fragment that bleeds into the margin: measured on 2026-09-24, a
`break-inside: avoid` block with negative side margins had all six fragments at x = 18.91 against a
content box at x = 56.69, the filter discarded every one of them, the first fragment (335.81 px
against 340.16 px) was measured instead of the 1865.61 px sum, and the document came back `clean`.
It is reported again.

**Fragments are correlated by authoring-source id, and a split block that cannot be correlated is
declined, not measured on one piece.** A split block whose fragments carry no `sid` — every block of
a `--no-source-map` run, or an element a script created — has nothing to join its fragments by, and
neither has one whose sid does not account for exactly the fragments the snapshot counted.
`layout/unbreakable-block-too-tall` used to measure the first fragment of such a block, which
compares a piece with the page and can call a six-page block clean. It now declines it as
`env/invalid-measurement`, which counts against the rule's coverage floor: the run ends
`insufficient-coverage` (exit 4) rather than `clean`. An unsplit block without a sid is the whole
block and is still measured. In a `--no-source-map` run a split block does not reach the rule today:
measured on 2026-09-24, the sid-less source join refuses it first (`checker-crashed`, exit 3). The
decline is what remains once that join can join fragments.

**Naming an off-by-default rule in a config file turns it on, even with only options.** `rules` is
read as "the caller has an opinion about this rule": `false` disables, anything else enables, and
that includes an options object such as `{ "layout/half-empty-page": { "minNetFill": 0.4 } }`. For
the twelve rules that are on anyway this is invisible; for the five that are not, it means tuning one
also activates it. That is the intended reading — configuring a rule you do not want is not a
thing anyone does — but it is not obvious, so it is written down.

**Page fill counts glyph boxes, not line boxes, and has no ceiling.** `netFill` merges the
vertical bands of every text run's client rectangles — the glyph content area, not the line box —
and of replaced elements, and divides by the content box height. Half-leading and block margins
never enter it, so a page no further line would fit on reads roughly glyph height over line pitch,
which the font and the leading set. Measured on full pages that are not the last of their document
(Chromium 141 on Linux, Paged.js 0.4.3, the machine's default serif and sans-serif; not re-measured
on the current Chrome that CI runs): 0.58–0.72 at `line-height: 1.5`, 0.51–0.54 at 2, 0.34–0.36 at
3 (12 pt on A5 and 11 pt on A4). Both page-fill rules read this quantity. `layout/half-empty-page`
now also checks bottom space against twice the smallest positive line height recorded for a visible
boxed block on the page. Low coverage with less room than those two line heights does not warn. Natural
document-end low coverage is accepted, and outgoing forced low coverage without a late start
declines. A late start can still warn; unavailable line height does not invent a measurement.
These are bounded guards, not a new fill quantity or proof of avoidability. The rule stays
experimental, default-off and non-gating. `layout/orphaned-continuation-page` judges only a page whose content ends on it:
the next page does not open with its text running on, because a page whose text runs on and opens
the next page stopped for want of room. On a page it does judge it still reads net fill, so at
`line-height: 3` every such page falls below its 0.50 threshold however full it is and whatever
follows it: measured, 11 of 13 lines before a figure that did not fit read 0.29, and a tail page
filled to its last line 0.34. The "running on" test relies on the collector keeping margin-box
content out of the snapshot, as this release's collector does: a clone in a side margin box lies
inside the content box and would count as running text. A line-box fill, each text rectangle
widened to its line height, is the named next step for the net fill. It changes the snapshot shape and the quantity
behind the public options `minNetFill` and `maxNetFill`, which needs an owner decision, and it is
not in this release. None of these readings is a calibration.

**Which block a split belongs to is read from four recorded facts and line geometry.** The
snapshot records a block's lines from every text node beneath it and carries no parent link, so a
wrapper and the paragraph inside it hold the same line boxes. `layout/widow` and `layout/orphan`
count a line as a block's own when the collector saw text on it whose nearest block container is
that block (`TextLine.ownText`, retained in Snapshot 7), and count only the run of the block's own lines next to
the break. The run ends at an in-flow nested block and passes over a float, a positioned box or an
inline-level box beside the block's text, which the recorded `display`, `float` and `position` tell
apart; and a run is judged only when the run on the other side of the break, in the block's
fragment joined by source id, is own text too. Checked against a probe of the same documents with
plain Paged.js and Range rectangles, at four thresholds each, on patched Chromium 141: 24 layouts,
all 96 judgements agreeing, and a second set of 19 layouts, 70 of 76 agreeing, where the six
disagreements are the two custom-element layouts at the three stricter thresholds — splits no rule
sees, and none reported wrongly. Pinned in `tests/live/rule-targets.test.ts`. On the first-party
robustness document (`dargel-kleingewerbe`) three `layout/orphan` findings and one `layout/widow`
finding were wrappers around nested blocks and are gone. What remains unseen: a block container the
snapshot does not record — a custom element, a `<span style="display: block">` — owns its text, so
its splits are not judged and the block around it is not judged on those lines; a split block
without a source id is judged on its own side of the break only; and a `display: contents` element
whose lines no recorded block holds is declined (`env/invalid-measurement`), not judged by its own
value. `type/excessive-word-spacing` asks about the text rather than its container: it gives a line
to the deepest record that records it, by geometry, because that element's font set the gaps, and
takes whether the line is justified from its block container; there, text of a block's own lying
between two nested blocks on one line (between two floats) is taken for theirs. Three more limits
of the fragmentation rules, found by an independent verification and not fixed in this release: a
recorded block inside an UNRECORDED inline-level box (a `<p>` in a `<span style="display:
inline-block">` or `inline-flex`) is taken for an in-flow block, so its lines end the surrounding
block's run and can give a false `layout/orphan` or `layout/widow` — the pass-over of inline-level
boxes holds only for boxes the snapshot records; text in an unrecorded absolutely positioned or
floated box counts as the surrounding block's own lines; and lines are grouped by the top edge of
their text rectangles within 0.5 px, so an inline `<code>`, `<sup>` or badge at another height
than its line forms a line of its own, which both these rules and `type/excessive-word-spacing`
count as one (the last predates this release).

**The natural space comes from the font, or from the layout where a canvas cannot reproduce the
font.** `type/excessive-word-spacing` divides by the advance of one space in the block's computed
font plus its `letter-spacing`, times its effective `zoom`, measured with a canvas inside the page
once `document.fonts` reports the font loaded. Where a canvas cannot reproduce the font —
`font-variation-settings` beyond a `wght` that restates the weight, `font-size-adjust`, a
non-keyword `font-stretch`, synthesised caps other than `small-caps`, a font not yet loaded — the
layout is sampled instead, pooled over the document per layout key (font, caps, `letter-spacing`,
`word-spacing`, variation settings, `font-size-adjust`, `font-kerning`, zoom): gaps between two
consecutive words of one text node (in left-to-right text; in right-to-left text the words are
paired in visual order and a gap between two text nodes can be sampled, which pollutes the divisor
only if every sample of the key is polluted alike, since samples that disagree decline the block)
whose element computes that key, separated by collapsible
whitespace only, on the last line of the last fragment of a justified block that is its own block
container, has no nested source block and whose `text-align-last` does not justify that line. The
median is taken only when every sample lies within 0.1 px or 3 % of it. A block for which neither
source gives a value is declined as `env/invalid-measurement` and counted against coverage, so a
document in which more than half of the justified blocks are declined ends `insufficient-coverage`
(exit 4). Gaps set in an inline element in another font or size are still measured against the
block's own space (a monospace `<span>` in serif read 2.41× on natural spaces); an inline element's
own `word-spacing` is not judged. `tests/live/rule-targets.test.ts` pins ten canvas-measured font
settings against their unjustified last lines and the two layout-measured ones against an
independent one-line control each (within 0.05 px; measured within 0.03 px on patched Chromium 141
with the machine's default fonts), and CI re-takes exactly those. No web font (`@font-face`) is
among them: on the Chromium 141 these changes were developed on, a document loading one does not
reach a quiescent state, so the pin could not be recorded there. Right-to-left text is not judged
at all, and this predates the release: word gaps are read in text order, which in right-to-left
text runs against their positions, so every gap reads negative and is skipped, and the block is
reported as measured with a largest factor of 0.


## Conservative figure checks

The two figure checks are warnings and off by default. No calibration or complete figure model is claimed. Caption separation supports one authored image or inline SVG with positively visible geometry,
or one source-matched table with actual visible-cell unions, and one visible caption fragment.
An image body requires one body page; a table may span pages and uses authored caption order
to compare the first or last body page. Missing order or ambiguous table membership declines. It never substitutes a figure wrapper for an image. Multiple bodies, split image bodies, hidden/mismatched geometry, several captions, missing
source addressing or unsupported flow decline explicitly. SVG body visibility requires a visible painted primitive; use-only/empty SVGs may be declined. A measured split does not establish the break cause, author intent, or that a keep remedy will fit.

Dangling references check fragment-only hrefs labelled Figure/Fig./Abbildung/Abb. or
Table/Tbl./Tabelle/Tab. plus a number. All authored IDs are inventoried, including inline IDs;
legacy `<a name>` targets are used only when no ID has that name. Duplicate targets or malformed
fragment encoding decline. A stored figure inventory lacking named anchors cannot prove that
a target absent from IDs is missing; that block declines. One candidate/finding aggregates a
containing source block. Printed numbering, exact inline link placement, external links and target
visibility remain outside scope. Script-bearing/base-URI figure source still declines. Missing
legacy inventories remain nonmeasurements. Source/delivery claims keep their existing requirements.

SVG body identity uses a full normalized content hash. Only observed paginator/parser metadata,
comments and non-text formatting nodes are normalized; meaningful SVG text whitespace and authored
drawing/style/content fields remain bound. Authored ownership of the normalized paginator
`data-ref` or `data-next-break-before` fields makes the source inventory unavailable rather
than discarding potentially meaningful source semantics. Source/runtime mismatch declines, and a wrapper box
cannot substitute for a painted body.

## Bounded table continuation checks

The two table checks are warnings, default-off and uncalibrated. They require a visible existing
header, exact row/cell membership and order, unchanged content, unit spans and measured cells.
Source-script presence alone does not prevent this bounded measurement, but an unknown runtime
table, a missing source row or changed content does. Missing inventory, headerless tables, split
data rows, spanning cells, multicolumn/vertical flow and unusable geometry decline. An authored
`thead` or an initial contiguous all-`th` row run supplies the header; a data row never does.
Snapshot 7 represents positive integer spans. Valid `rowspan="0"` row-group growth and raw
attributes outside that representation withhold the optional table inventory; enabled table
checks decline explicitly while unrelated default checks continue. Browser recovery of malformed
span attributes is not modeled, and an unsupported zero is never replaced by a unit span.
The header check observes lost column context. The drift check observes changed cell tracks
relative to each fragment's origin, with a chosen 2 CSS px default tolerance. Neither proves
author intent or a particular CSS cause. Repeated-header and column-width repair suggestions
are untested; validate row preservation, wrapping and overflow after any change.

## Network lifecycle classification in 0.10

Transport completion uses public CDP request IDs, including redirect hops; a Puppeteer request
object or repeated URL is not proof of completion. An unconsumed local denied Fetch can produce
a terminal `Network.loadingFailed` after its HTTP403 response. This narrowly observed case is
accepted for same-origin Fetch/XHR, or a static origin-relative stylesheet/script route that the
existing standalone asset-closure policy has independently classified as an omitted deployment
asset. The latter set comes from source discovery, never user configuration or a dynamic request.
Both require the same request's observed403 response and a cancelled `net::ERR_ABORTED` terminal
event. It stays pending until that event. Other transport
failures, malformed or unjoined observations, remote requests and failed successful responses
remain fatal. Local required-resource roles and the independent font/image geometry barriers
still apply. This does not establish author intent or excuse an incomplete resource body.

A failure diagnostic can name the observed logical resource route and status. It strips host
directories and URL credentials, query strings and fragments; canonical resource provenance
remains a separate record. This is not a universal anonymous-path promise for arbitrary authored
filenames.
