# `type/straight-quotes`

| | |
|---|---|
| severity | warn |
| threshold | occurrences: 0 permitted |
| proof source | — |
| calibrated | **no** |

## What is checked

A straight quotation mark or apostrophe appears in typeset prose.

## Why

A warning and nothing stronger: the same characters are legitimate as the inch mark and the arc minute.

## Limits and known false alarms

A digit immediately before the character exempts it. A program quotation inside `code` is excluded structurally.

Configuration may add ancestor tag names with `excludeTags`, for example
`{"rules":{"type/straight-quotes":{"excludeTags":["samp"]}}}`. These are HTML tag names, not CSS
selectors; they are lower-cased and deduplicated before the rule runs.

## Calibration

`calibrated: false`. The threshold has not been fitted to a corpus of real documents with
human-checked truth; no such corpus exists for this project. Every finding says so, and the
report says so in `measurement.calibrated`. That is the honest state, not a defect — but it is
also why this rule ships with the severity it has.

## Remediation

<!-- begin generated remediation: type/straight-quotes -->
Straight typewriter quotation marks (' or ") appear in running prose. Replace them with the curly pair for the configured locale — '&bdquo;'/'&ldquo;' for 'de-DE' (the default), '&ldquo;'/'&rdquo;' for 'en-*' — or use the <q> tag with a matching CSS 'quotes' value. Where the straight mark is deliberate, put it inside <code>, <pre>, <kbd>, <samp> or <var> — this rule never measures those — or name further container tags in its 'excludeTags' option.
<!-- end generated remediation: type/straight-quotes -->

## Examples

### Firing case (trigger)

```html
<p lang="de">Der Autor schrieb: "Dies ist ein wichtiger Punkt."</p>
```

### Non-firing case (remedied)

```html
<p lang="de">Der Autor schrieb: &bdquo;Dies ist ein wichtiger Punkt.&ldquo;</p>
```

